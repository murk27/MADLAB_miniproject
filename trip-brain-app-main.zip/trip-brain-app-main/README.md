# Travel Brain 🌍✈️

Welcome to Travel Brain! Your go-to app for personalized travel suggestions tailored to your interests and dislikes. Get travel notes, historical background, and more!

## Features 🌟

- **Travel Suggestions 🗺️**: Get destinations that match your vibe.
- **Insightful Information 📚**: Learn more about each place.
- **gRPC Communication ⚡**: Fast and efficient backend communication.
- **Offline Support 📴**: No internet? No problem!

## Demo video

https://github.com/Pr0nE/trip-brain-app/assets/25032492/fbfaa7cf-057b-4380-acd9-17a3329fff5c


## Architecture 🏗️

This project is organized into three main layers: UI, Data, and Domain. Each layer is in its own package to prevent code mixing.

- **UI Package 🎨**: Widgets only, depends on domain.
- **Data Package 💾**: Classes that produce domain language.
- **Domain Package 🛠️**: Interfaces and models only.
- **App Package 📦**: The glue that binds everything.

📝 **Upcoming**: Detailed article on architecture.

## Getting Started 🚀

### Prerequisites 🛠️

- Flutter SDK
- Docker
- Firebase project
- OpenAI API Key
- Unsplash API Key
- Google Client ID

### API Keys and Client ID Setup 🔑

1. **OpenAI API Key**: Required for natural language processing features.
2. **Unsplash API Key**: Needed for fetching dynamic travel images.
3. **Google Client ID**: For Google Sign-In authentication.

### Firebase Setup 🔥

Provide these files for Firebase:

- `android/app/google-services.json`
- `lib/firebase_options.dart`
- `ios/firebase_app_id_file.json`
- `ios/Runner/GoogleService-Info.plist`

### Step 1: Env Setup 🌱

Rename `.env.example` to `.env` and fill it out.

```bash
mv .env.example .env
```

📝 **Note**: Open `.env` and complete the variables.

### Step 2: Docker Up 🐳

Run this to start Docker containers:

```bash
docker compose up -d
```

🟢 **Success**: Containers should be running.

### Step 3: Flutter Run 🏃‍♂️

Run your Flutter app:

```bash
flutter run
```

## Contributing 🤝

We welcome your help! Here's what you can do:

0. **Backend Refactor 🛠️**: Assistance needed for refactoring Go code.
1. **Platform Testing 📱**: Help needed for iOS and web.
2. **Testing 🧪**: Tests are in progress.
3. **UI/UX 🎨**: Room for improvement.

## License 📄

[MIT](https://github.com/Pr0nE/trip-brain-app/blob/main/LICENSE)

## Contact 📞

Questions? Reach out to [Mohammad Teimouri](mailto:moshi1376@yahoo.com).
