enum AuthProvider { google }
